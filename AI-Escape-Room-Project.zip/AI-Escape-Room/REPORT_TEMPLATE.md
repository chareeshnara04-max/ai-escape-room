# AI-Powered Escape Room — Short Project Report

**Student:** [Your name]  
**Course:** [Course name]  
**Project:** AI Escape Room — Mystery Library

## 1. Objective

The objective of this project was to develop an interactive escape-room application using Python, Streamlit and a freely accessible Large Language Model API. The player explores a locked library, investigates objects, discovers clues, solves a combination puzzle and unlocks the exit.

## 2. Version 1: Interactive AI Escape Room

Version 1 uses Streamlit as the user interface and Gemini as the Game Master. Players interact through natural-language messages. The room contains a desk, bookshelf, painting, locked drawer and exit door. The desk reveals the symbol order, the bookshelf and painting reveal the numbers, the drawer contains the final exit code, and the exit completes the game.

The main limitation is that the LLM is responsible for interpreting actions and remembering progress. LLM responses can be inconsistent, may forget previous actions, or may accept instructions that conflict with the game rules.

## 3. Version 2: Reliable AI Escape Room

Version 2 introduces a Python game engine with structured state fields for investigated objects, drawer status, exit status and inventory. Python validates prerequisites and combinations before any success event is produced. Gemini is used only to narrate a validated event. If the API call fails, the application can display the trusted Python event instead.

This separation improves consistency because the LLM does not decide whether the drawer or exit is unlocked.

## 4. Testing and results

The project includes automated tests for administrator impersonation, secret-code requests, incorrect drawer combinations, opening the drawer before investigating clues, opening the exit too early, successful escape and unknown objects. Summarise the actual results from your test run here; do not claim tests passed unless you ran them.

## 5. Conclusion and limitations

The project demonstrates a progression from a conversational LLM prototype to a more reliable hybrid application. Version 2 improves rule enforcement by keeping game state and puzzle validation in Python. The natural-language parser currently uses keyword matching, so more flexible intent recognition and additional adversarial tests could be future improvements.
